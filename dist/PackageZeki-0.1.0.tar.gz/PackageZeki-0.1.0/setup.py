from setuptools import setup, find_packages

setup(
    name="PackageZeki",                                 # Nombre del paquete
    version="0.1.0",                                    # Versión inicial
    packages=find_packages(),                           # Paquetes a incluir
    description="Un paquete pip simple de saludo",      # Breve descripción
    author="TheZeki96",                                 # Tu nombre
    author_email="eric.jara.p@uni.pe",                  # Tu correo electrónico
    url="https://github.com/TheZeki96/PackageZeki",     # URL del proyecto
)